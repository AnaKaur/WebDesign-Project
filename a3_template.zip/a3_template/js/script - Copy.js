
function validateForm(){
	var isValid = false;
	// Validate the form according to validation requirements
	var name = document.registration.name.value;
	var username = document.registration.username.value;
	var email = document.registration.email.value;
	var password = document.registration.password.value;
	var password = document.registration.password.value;
	var password2 = document.registration.password2.value;
	var age = document.registration.age.value;
	var bio = document.registration.bio.value;
	var gender = document.registration.gender.value;
	var agreement = document.registration.agreement.value;
	
	
	
	if(isValid){
		//Print the form input values into output div
		$("#result_list").empty();
		$("#result_list").append("<li>Your Name: " + name + "</li>");
		$("#result_list").append("<li>Your Userame: " + username + "</li>");
		$("#result_list").append("<li>Your Email: " + email + "</li>");
		$("#result_list").append("<li>Your password: " + password.replace(/./g, "*") + "</li>");
		$("#result_list").append("<li>Your Age: " + age + "</li>");
		$("#result_list").append("<li>Your Bio: " + bio + "</li>");
		$("#result_list").append("<li>Your Gender: " + gender + "</li>");
	}
	return false;
}