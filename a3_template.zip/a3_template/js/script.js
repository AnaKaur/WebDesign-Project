
function validateForm(){
	var isValid = false;
	// Validate the form according to validation requirements
	var name = document.registration.name.value;
	var username = document.registration.username.value;
	var email = document.registration.email.value;
	var password = document.registration.password.value;
	var password = document.registration.password.value;
	var password2 = document.registration.password2.value;
	var age = document.registration.age.value;
	var bio = document.registration.bio.value;
	var gender = document.registration.gender.value;
	var agreement = document.registration.agreement.value;
	
	
	
	if(isValid){
		//Print the form input values into output div. Append each text/value as a list item of the ul#result_list using jQuery
	}
	return false;
}