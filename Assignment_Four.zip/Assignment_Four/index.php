<?php 

session_start();
    
if(!isset($_COOKIE['firstVisit'])) {
    setcookie('firstVisit', time(),time()+365*24*60*60);
    echo "<h4>“Welcome! you are visiting for the first time</h4>";
}
else
{
    $datetime1 = new DateTime();
    $datetime1->setTimestamp(intval($_COOKIE['firstVisit']));
    $datetime2 =new DateTime();
    $interval = $datetime2 ->diff($datetime1);
    if(isset($_SESSION["name"]))
    {
        echo "<h4>Welcome back ".$_SESSION["name"]."! You first visited this page ".$interval->format('%a')." days before.</h4>";
    }
    else if(isset($_COOKIE["name"]))
    {
        echo "<h4>Welcome back ".$_COOKIE['name']."! You first visited this page ".$interval->format('%a')." days before.</h4>";
    }
}

if(isset($_POST['name']))
{
    
    $_SESSION["name"] = $_POST['name'];
    $_SESSION["date_of_birth"] = $_POST['date_of_birth'];
    setcookie('name', $_POST['name'],time()+365*24*60*60); 
}


if(isset($_SESSION['name']))
{
    $datetime1=DateTime::createFromFormat('m/d/Y',$_SESSION['date_of_birth']);
    $datetime2 =new DateTime();
    $interval = $datetime2 ->diff($datetime1);
    echo $interval->format("<h4>You are %y years, %m months, %d days old.</h4>");
    
}



?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Assignment4</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		
   <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
   
  <script>
  $(function() {
    $( "#date_of_birth" ).datepicker({
                changeMonth: true,
                changeYear: true,
                defaultDate: new Date('2016', '11', '02'),
                setDate: new Date('2016', '11', '02')
            });
        });
  </script>
    <link rel="stylesheet" type="text/css" href="./slick/slick.css">
  <link rel="stylesheet" type="text/css" href="./slick/slick-theme.css">
  <style type="text/css">
    html, body {
      margin: 0;
      padding: 0;
    }

    * {
      box-sizing: border-box;
    }

    .slider {
        width: 50%;
        margin: 100px auto;
    }

    .slick-slide {
      margin: 0px 20px;
    }

    .slick-slide img {
      width: 100%;
    }

    .slick-prev:before,
    .slick-next:before {
      color: black;
    }


    .slick-slide {
      transition: all ease-in-out .3s;
      opacity: .2;
    }
    
    .slick-active {
      opacity: .5;
    }

    .slick-current {
      opacity: 1;
    }
  </style>
</head><body>
 
 
 <div id="form-container">
         <form id="registration" name="registration" autocomplete="off" method="post" action="index.php">
            <div>
                <label for="name">Your name</label>
                <input id="name" name="name" type="text"/>               
            </div>
            <div >
                <label for="date_of_birth">Enter your Date of Birth: </label>
                <input type="text" id="date_of_birth" name="date_of_birth" >
                <input id="submit" name="submit-btn" type="submit" value = "Submit" />
            </div>
        </form>
  </div> 
  <div id="welcome_message">
<?php
error_reporting(-1);

ini_set('display_errors', 'On');

// Another way to debug/test is to view all cookies
?>

  <section class="vertical-center-3 slider">
    <div>
      <img src="images/AS.jpg">
    </div>
    <div>
      <img src="images/KS.jpg">
    </div>
    <div>
      <img src="images/QS.jpg">
    </div>
    <div>
      <img src="images/JS.jpg">
    </div>
    <div>
      <img src="images/10S.jpg">
    </div>
    <div>
      <img src="images/9S.jpg">
    </div>
    <div>
      <img src="images/8S.jpg">
    </div>
    <div>
      <img src="images/7S.jpg">
    </div>
    <div>
    </div>
  </section>



<script src="./slick/slick.js" type="text/javascript" charset="utf-8"></script>
  <script type="text/javascript">
    $(document).on('ready', function() {
      $(".vertical-center-3").slick({
        dots: true,
        vertical: true,
        centerMode: true,
        slidesToShow: 3,
        slidesToScroll: 3
      });
    });
</script>

</body>
</html>