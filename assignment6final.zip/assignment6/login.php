<?php 
require_once "dbconnect.php";
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
if(isset($_POST["submit"])){
	$email = $_POST["email"];
	$password = $_POST["password"];

	$query = "SELECT * FROM employees WHERE email = '$email' AND password = '$password'";
	
	//echo $query;
	echo "<h2></h2>";
	try{
		$stmt = $conn->query($query);
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		//print_r($row);
		if($row === false){
			echo "<p>Login incorrect.</p>";
		} else{
		    $_SESSION['full_name'] = $row['first_name']." ".$row['last_name'];
		    echo $_SESSION['full_name'];
			header("Location: index.php");
			
		}
	}
	catch(PDOException $e)
	{
		echo $query . "<br>" . $e->getMessage();
	}
}
else
{
    session_destroy();
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
	<h4>Please Login</h4>
	<form action="" method="post">		
		<p>Email:<input type="text" name="email" autocomplete="off"></p>
		<p>Password:<input type="password" name="password" autocomplete="off"></p>
		<p><input type="submit" name="submit" value="Login"/></p>
	</form>
</body>
</html>
