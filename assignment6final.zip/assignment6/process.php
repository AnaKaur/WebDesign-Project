<?php
require_once "dbconnect.php";
session_start();

if(isset($_GET["get_emp"])){
	$page = $_GET["page"];
	$page_size = $_GET["pagesize"];
	$search_str = $_GET["searchstring"];
	$offset = (intval($page) - 1) * $page_size;
	$query = "SELECT SQL_CALC_FOUND_ROWS employee_id, first_name, last_name, email, password FROM employees 
	LIMIT $offset, $page_size";
	if ($search_str !="")
	{
	    $query = "SELECT SQL_CALC_FOUND_ROWS employee_id, first_name, last_name, email, password FROM employees 
	        where first_name like'%{$search_str}%' or last_name like'%{$search_str}%' or email like'%{$search_str}%'  LIMIT $offset, $page_size";
	}

	$stmt = $conn->query($query);
	$rows = array();
	while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
		$rows[] = array('employee_id' => $row["employee_id"], 'first_name' => $row["first_name"], 'last_name' => $row["last_name"], 'email' => $row["email"], 'password' => $row["password"]);
	}

	$query2 = "SELECT FOUND_ROWS() AS total";
	$stmt2 = $conn->query($query2);
	$row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
	$total = $row2["total"];
	$return_array = array("total" => $total, "rows" => $rows);
	print_r(json_encode($return_array));
}

if(isset($_POST["action"])){
	$action = $_POST["action"];
	if($action == "delete"){
		deleteEmployee($_POST["employee_id"]);
		return;
	}

	$employee = $_POST["employee"];
	$first_name = $employee["first_name"];
	$last_name = $employee["last_name"];
	$email = $employee["email"];
	$password = $employee["password"];
	$employee_id = $employee["employee_id"];

	if($action == "add"){
		$query = "INSERT INTO employees (first_name, last_name, email, password)
		VALUES (:first_name, :last_name, :email, :password)";
	} else if($action == "edit"){
		$query = "UPDATE employees SET first_name = :first_name, last_name = :last_name, email = :email, password = :password
		WHERE employee_id = :employee_id";
	}
	

	$stmt = $conn->prepare($query);
	$stmt->bindParam(':first_name', $first_name);
	$stmt->bindParam(':last_name', $last_name);
	$stmt->bindParam(':email', $email);
	$stmt->bindParam(':password', $password);

	if($action == "edit"){
		$stmt->bindParam(':employee_id', $employee_id);
	}

	try{

		$stmt->execute();
		$conn = null;
		print "success";
		return;

	}
	catch(PDOException $e)
	{
		print("error");
	}
}

function deleteEmployee($employee_id){
	global $conn;
	$query = "DELETE FROM employees WHERE employee_id = :employee_id";

	try{
		$stmt = $conn->prepare($query);
		$stmt->bindParam(':employee_id', $employee_id);
		$stmt->execute();

		print "success";
		return;
	}
	catch(PDOException $e)
	{
		print "error";
	}
}

?>
