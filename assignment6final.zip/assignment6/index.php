<?php
require_once "dbconnect.php";
session_start();
if(!isset($_SESSION['full_name']))
{
    header("Location: login.php");    
}

?>

<!DOCTYPE html>
<html>
<head>
	<titleAssignment 6</title>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<style type="text/css">
		.success{
			color: green;
		}
		.error{
			color: red;
		}
		.container {
         display: flex;
        width: 100%;
        outline: 1px solid black;
        }

            

        .last-item {
              margin-left: auto;
        }
		#emp_name{
			color: red;
		}
	</style>
	<script type="text/javascript">
		$(document).ready(function() {
			loadEmployees(1,25,"");

			function loadEmployees(page,pagesize,searchstring){
				$("#employees_tbl tbody").html("");
				$.ajax({
					method: "GET",
					url: "process.php",
					data: {get_emp: 1, page: page, pagesize: pagesize, searchstring: searchstring},
					dataType: "json"
				}).done(function (result) {
					if (result == "error") {
						$(".error").text("Could not load data.").show();
					} else {
						var total = result.total;
						var rows = result.rows;
						var pages= Math.ceil((0.0+total)/pagesize);
						var row, row_html;
						for (var i = 0; i < rows.length; i++) {
							row = rows[i];
							row_html = "<tr data-id='" + row.employee_id + "'>";
							row_html += "<td class='emp_id'>" + row.employee_id + "</td>";
							row_html += "<td class='fname'>" + row.first_name + "</td>";
							row_html += "<td class='lname'>" + row.last_name + "</td>";
							row_html += "<td class='email'>" + row.email + "</td>";
							row_html += "<td class='passwd'>" + row.password + "</td>";
							row_html += "<td><a href='' class='edit_btn'>Edit</a> / ";
							row_html += "<a href='' class='delete_btn'>Delete</a>";
							row_html += "</td>";
							row_html += "</tr>";
							$("#employees_tbl tbody").append(row_html);
						    
						}
						row_html = "";
                       
						$("#pagination_nav").html("");
						for (var i = 0; i < pages; i++) {
						    row_html +="<li class=\"page-item\"><a class=\"page-link\" href=\"#\">"+(i+1).toString(10)+"</a></li>";
						}
						row_html +="<li>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</li>"
						
						row_html+="<li class=\"dropdown\" id=\"size_list\" style=\"margin-left: auto;\" ><a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">"+(pagesize).toString(10)+"<span class=\"caret\"></span></a>\n" +
                            "<ul class=\"dropdown-menu\">\n" +
                            "<li><a class=\"size-link\" href=\"#\">10 per Page</a></li>\n" +
                            "<li><a class=\"size-link\" href=\"#\">25 per Page</a></li>\n" +
                            "<li><a class=\"size-link\" href=\"#\">50 per Page</a></li>\n" +
                            "</ul>\n" +
                            "</li>";
						$("#pagination_nav").append(row_html);
						
					}
				}).fail(function (jqXHR, textStatus, error) {
					console.log(jqXHR.responseText);
					console.log(textStatus);
				});
			}



			$("#add_emp_button").on("click", function(event){
				$("#addEditModalTitle").html("Add new employee");
				$('#addEditModal').modal('show');
				$("#employee_id, #first_name, #last_name, #email, #password").val("");
				event.preventDefault();
			});
			$("#logout_button").on("click", function(event){
				window.location.replace("login.php");
				event.preventDefault();
			});
			
			$("#search_emp_button").on("click", function(event){
				$("#searchModalTitle").html("Add new employee");
				$('#searchModal').modal('show');
				$("#search_text").val("");
				event.preventDefault();
			});

			$(document).on("click", ".edit_btn", function(event){
				var $row = $(this).parents("tr").first();
				$("#employee_id").val($('.emp_id', $row).text());
				$("#first_name").val($('.fname', $row).text());
				$("#last_name").val($('.lname', $row).text());
				$("#email").val($('.email', $row).text());
				$("#password").val($('.passwd', $row).text());
				$("#addEditModalTitle").html("Edit employee");
				$('#addEditModal').modal('show');
				event.preventDefault();
			});

			$(document).on("click", ".delete_btn", function(event){
				var $row = $(this).parents("tr").first();
				var employee_id = $('.emp_id', $row).text();
				$("#employee_id_del").val($('.emp_id', $row).text());
				var emp_name = $('.fname', $row).text() + " " + $('.lname', $row).text();
				$("#emp_name").html(emp_name);
				$("#deleteModal").modal("show");
				event.preventDefault();
			});
			
			

			$(".save_employee").on("click", function() {
				var emp = new Object();
				emp.employee_id = $("#employee_id").val();
				emp.first_name = $("#first_name").val();
				emp.last_name = $("#last_name").val();
				emp.email = $("#email").val();
				emp.password = $("#password").val();

				var action = "add";
				if(emp.employee_id){
					action = "edit";
				}
				$(".success, .error").html("").hide();
				$.ajax({
					method: "POST",
					url: "process.php",
					data: {action: action, employee: emp}
				}).done(function (result) {
					if (result == "error") {
						$(".error").text("Could not save data.").show();
					} else {
						$(".success").text("Successfully saved data.").show();
					}
					loadEmployees(1,25);
					$('#addEditModal').modal('hide');

				}).fail(function (jqXHR, textStatus, error) {
					console.log(jqXHR.responseText);
					console.log(textStatus);
				});
			});

			$(".delete_employee").on("click", function() {
				var employee_id = $("#employee_id_del").val();
				
				$(".success, .error").html("").hide();
				$.ajax({
					method: "POST",
					url: "process.php",
					data: {action: "delete", employee_id: employee_id}
				}).done(function (result) {
					if (result == "error") {
						$(".error").text("Could not delete employee.").show();
					} else {
						$(".success").text("Employee deleted successfully.").show();
					}
					loadEmployees(1,25);
					$('#deleteModal').modal('hide');

				}).fail(function (jqXHR, textStatus, error) {
					console.log(jqXHR.responseText);
					console.log(textStatus);
				});
			});
			$(".search_employee").on("click", function() {
			    
				loadEmployees(1,parseInt($("#size_list").text()),$("#search_text").val());
				$(".success, .error").html("").hide();
				
			});
			$(document).on("click", ".size-link", function(event){
                event.preventDefault();
                var tag = $(this);
                if(tag.text()=="25 per Page")
                {
                    loadEmployees(1,25,$("#search_text").val());
                }
                else if(tag.text()=="10 per Page")
                {
                    loadEmployees(1,10,$("#search_text").val());
                }
                else if(tag.text()=="50 per Page")
                {
                    loadEmployees(1,50,$("#search_text").val());
                }
            });
			$(document).on("click", ".page-link", function(event){
                event.preventDefault();
                var tag = $(this);
                loadEmployees(parseInt(tag.text()),parseInt($("#size_list").text()),$("#search_text").val());
            });
		});
	</script>
</head>
<body>
	<h2 class="success"></h2>
	<h2 class="error"></h2>
	<div class="container">
	<p><?php
    echo "Welcome back, ".$_SESSION['full_name'];
    ?>
    <p>
    <p class="last-item"><a id="logout_button" href="">Logout</a></p></div>
	<div><a id="add_emp_button" href="">Add a new employee</a></div>
	<div >
	    Search: <input type="text"   size="65" name="search_text" id="search_text" 
	    placeholder="Search with a first name. last name, or email" autocomplete="off">
		<button type="button" class="btn btn-primary search_employee">Search</button>
	</div>
	<div>
		<nav id="employees_nav">
          <ul class="pagination" id="pagination_nav">
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Page Size <span class="caret"></span></a>
                <ul class="dropdown-menu">
                <li><a href="#">10 per Page</a></li>
                <li><a href="#">25 per Page</a></li>
                <li><a href="#">50 per Page</a></li>
                </ul>
            </li>
            <li class="page-item"><a  href="" class="page-link">2</a></li>
          </ul>
        </nav>
		<table border="1" id="employees_tbl">
			<thead>
				<tr>
					<th>Employee ID</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Email Address</th>
					<th>Password</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>

			</tbody>
			
		</table>
		
	</div>

	<div class="modal fade" id="addEditModal" tabindex="-1" role="dialog" aria-labelledby="addEditModalTitle" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="addEditModalTitle">Add employee</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="" method="post" id="add_edit_form">
						<input type="hidden" name="employee_id" id="employee_id">
						<p>First Name:<input type="text" name="first_name" id="first_name" autocomplete="off"></p>
						<p>Last Name:<input type="text" name="last_name" id="last_name" autocomplete="off"></p>
						<p>Email:<input type="text" name="email" id="email" autocomplete="off"></p>
						<p>Password:<input type="password" id="password" name="password" autocomplete="off"></p>
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary save_employee">Save changes</button>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalTitle" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="deleteModalTitle">Deleting employee</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<h4>Deleting <span id="emp_name"></h4>
						<form action="" method="post" id="delete_form">
							<input type="hidden" name="employee_id" id="employee_id_del">
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary delete_employee">Delete</button>
					</div>
				</div>
			</div>
		</div>
		
	</div>
		
	</body>
	</html>